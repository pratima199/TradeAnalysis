package com.tas.github.repository;

import com.tas.github.model.TradingEntity;
import org.springframework.data.jpa.repository.JpaRepository;

public interface TradingEntityRepository extends JpaRepository<TradingEntity, String> {
}
