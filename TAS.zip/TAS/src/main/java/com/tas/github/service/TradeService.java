package com.tas.github.service;

import com.tas.github.repository.TradingEntityRepository;
import com.tas.github.model.TradingEntity;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;
import java.io.BufferedReader;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.io.*;

@Service
public class TradeService {

    @Autowired
    private TradingEntityRepository tradingEntityRepository;

    public String readFromCSV(String fileName) {

        //System.out.print(fileName);

        // hardcoding for now, it works from API input as well
        fileName = "TradesEOD_5_May_2022.csv";
        ClassLoader classLoader = getClass().getClassLoader();
        InputStream inputStream = classLoader.getResourceAsStream(fileName);

        // the stream holding the file content
        if (inputStream == null) {
            //throw new IllegalArgumentException("file not found! " + fileName);
            return "No data/file found";
        }

        List<TradingEntity> listOfEntity = new ArrayList<>();
        Path pathToFile = Paths.get(fileName);

        // create an instance of BufferedReader
        // using try with resource, Java 7 feature to close resources
        try (InputStreamReader streamReader =
                     new InputStreamReader(inputStream, StandardCharsets.UTF_8);
             BufferedReader reader = new BufferedReader(streamReader)) {

            // read the first line from the text file
            String line = reader.readLine();

            line = reader.readLine();
            // loop until all lines are read
            while (line != null) {

                // the file, using a comma as the delimiter
                String[] attributes = line.split(",");

                TradingEntity entry = createEntry(attributes);

                // adding tradedata into ArrayList
                listOfEntity.add(entry);

                // read next line before looping
                // if end of file reached, line would be null
                line = reader.readLine();
            }

        } catch (IOException ioe) {
            ioe.printStackTrace();
        }
        if (!listOfEntity.isEmpty()) {
            tradingEntityRepository.save(listOfEntity);
        }

        return "Uploaded Data";
    }

    private TradingEntity createEntry(String[] metadata) {
        TradingEntity trade = new TradingEntity();
        trade.setOrderNum(metadata[0]);
        trade.setShareName(metadata[1]);
        trade.setShareId(metadata[2]);
        trade.setQuantity(Long.parseLong(metadata[3]));
        trade.setBuyOrSell(metadata[4]);
        trade.setPricePerShare(Long.parseLong(metadata[5]));
        trade.setCustomerId(metadata[6]);
        trade.setAccount(metadata[7]);
        trade.setFrontDeskOfficerId(metadata[8]);
        trade.setBranchCode(metadata[9]);
        trade.setTradingChange(Long.parseLong(metadata[10]));
        trade.setExchange(metadata[11]);
        trade.setTradeDateTime(metadata[12]);

        return trade;
    }

    // use to create entry through api
    public String createNewEntry(TradingEntity tradingEntity) {
        tradingEntityRepository.save(tradingEntity);
        return "create succesfully";
    }

    public List<TradingEntity> getFrontOfficeData(String id) {
        //TODO
        return null;
    }
}