package com.tas.github.model;

import com.fasterxml.jackson.annotation.JsonProperty;

import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class TradingEntity {

    public void TradingEntity () {
    }

    @Id
    private String orderNum;

    private String shareName;

    //@JsonProperty("share_id")
    private String shareId;

    private Long quantity;

    private String buyOrSell;

    private Long pricePerShare;

    private String customerId;

    private String account;

    private String frontDeskOfficerId;

    private  String branchCode;

    private Long tradingChange;

    private String exchange;

    private String tradeDateTime;

    public String getOrderNum() {
        return orderNum;
    }

    public void setOrderNum(String orderNum) {
        this.orderNum = orderNum;
    }
    public String getShareName() {
        return shareName;
    }

    public void setShareName(String shareName) {
        this.shareName = shareName;
    }
    public String getShareId() {
        return shareId;
    }

    public void setShareId(String shareId) {
        this.shareId = shareId;
    }
    public Long getQuantity() {
        return quantity;
    }

    public void setQuantity(Long quantity) {
        this.quantity = quantity;
    }
    public String getBuyOrSell() {
        return buyOrSell;
    }

    public void setBuyOrSell(String buyOrSell) {
        this.buyOrSell = buyOrSell;
    }
    public Long getPricePerShare() {
        return pricePerShare;
    }

    public void setPricePerShare(Long pricePerShare) {
        this.pricePerShare = pricePerShare;
    }
    public String getCustomerId() {
        return customerId;
    }

    public void setCustomerId(String customerId) {
        this.customerId = customerId;
    }
    public String getAccount() {
        return account;
    }

    public void setAccount(String account) {
        this.account = account;
    }
    public String getFrontDeskOfficerId() {
        return frontDeskOfficerId;
    }

    public void setFrontDeskOfficerId(String frontDeskOfficerId) {
        this.frontDeskOfficerId = frontDeskOfficerId;
    }
    public String getBranchCode() {
        return branchCode;
    }

    public void setBranchCode(String branchCode) {
        this.branchCode = branchCode;
    }
    public Long getTradingChange() {
        return tradingChange;
    }

    public void setTradingChange(Long tradingChange) {
        this.tradingChange = tradingChange;
    }
    public String getExchange() {
        return exchange;
    }

    public void setExchange(String exchange) {
        this.exchange = exchange;
    }
    public String getTradeDateTime() {
        return tradeDateTime;
    }

    public void setTradeDateTime(String tradeDateTime) {
        this.tradeDateTime = tradeDateTime;
    }
}
