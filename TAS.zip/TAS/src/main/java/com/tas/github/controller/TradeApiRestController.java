package com.tas.github.controller;

import com.tas.github.model.TradingEntity;
import com.tas.github.repository.TradingEntityRepository;
import com.tas.github.service.TradeService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpServletResponse;
import java.util.List;

@RestController
public class TradeApiRestController {

    @Autowired
    private TradeService tradeService;

    @Autowired
    private TradingEntityRepository tradingEntityRepository;

    @PostMapping("/uploadTradeData")
    public String uploadData(@RequestBody String filepath, HttpServletResponse response) {
        return tradeService.readFromCSV(filepath);
    }

    @GetMapping("/allTrade")
    public List<TradingEntity> getAllTrades() {
        return tradingEntityRepository.findAll();
    }

    @GetMapping("/getFrontOffice")
    public List<TradingEntity> getFrontOffice(@RequestBody String Id) {
        return tradeService.getFrontOfficeData(Id);
    }

}
